CLUB NILE — 333 CHARACTERS (1920s Egyptian speakeasy collection)
================================================================

images/1.png … images/333.png   Front portrait of every character (PNG,
                                 transparent background, ~336x648).
metadata.json                    Per-token name, tier and traits, in the
                                 order tokenId 1..333.

HOW THEY MAP TO THE GAME
------------------------
Every character is generated deterministically from its token id by
traitsForToken(id) inside games/clubnile.html — token #N ALWAYS renders
the same guest, both as this portrait and as the live in-game sprite
(all four walking directions, accessories and all).

PLAYABLE WHEN THE NFT IS OWNED
------------------------------
On entering Club Nile the game reads sessionStorage 'clubnile_session'
= { wallet, tokenId, name }. Whatever tokenId (1..333) is handed over,
the player walks in AS that character. The NFT gate just needs to verify
ownership of MembersOnly token #N and set tokenId=N before redirecting
to games/clubnile.html — no per-character art to host; the sprite is
built live from the same trait table these portraits came from.

TIERS
-----
common (210) · rare (81) · epic (30, metallic gowns/tuxes) ·
legendary (12, incl. the named one-offs: The Golden Idol #1,
Midnight Sheik #7, Silver Moonlight #33, The Emerald Vamp #77,
Pharaoh of Chips #100, The Ruby Baroness #222, The Last Chad #333).
